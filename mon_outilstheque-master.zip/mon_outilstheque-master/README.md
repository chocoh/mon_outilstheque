# Mon OutilsThèque

**Projet :**
Aplication de gestion de prèts d'outils divers.

**Instalation :**
  * I-Via composer
    - 'git clone https://github.com/chocoh/mon_outilstheque.git '
    - Créer une nouvelle bd sur PHPMyAdmin
    - Exporter la base de donnée qui vous avez récupérer dans le fichier bd


  * II-En téléchargement
    - Récupérer le fichier [ici](https://github.com/chocoh/mon_outilstheque.git)

**Licence :**
